$(document).ready(function () {
    $('#mug').click(function () {
        alert("JavaJam Mug Club Members get a 10% discount on each cup of coffee!");
    });
});